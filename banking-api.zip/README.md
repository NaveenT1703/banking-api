# Banking Api

Banking Transaction API using Java, Spring Boot, JWT, and MySQL.

## 🛠 Tech Stack
- Java 11
- Spring Boot
- Maven
- Spring Security + JWT
- MySQL

## 📦 Features
- User Registration/Login
- Balance Check
- Fund Transfer
- Role-based Access Control

## 🚀 How to Run
1. Clone this repo
2. Set DB credentials in `application.properties`
3. Run with `mvn spring-boot:run`

## 🧪 API Testing
Use Postman or Swagger (`/swagger-ui.html`) to test the APIs.
